package Banca;

public class Banca {

    public ContoCorrente Login(String proprietario, String password) {
        // TODO
        return new ContoCorrente();
    }

    public ContoCorrente Logout(String proprietario, String password) {
        // TODO
        return new ContoCorrente();
    }

    public void name(ContoCorrente mittente, ContoCorrente destinatario) {
        // TODO
    }

}
