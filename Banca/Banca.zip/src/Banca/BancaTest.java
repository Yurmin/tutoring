package Banca;

public class BancaTest {
    public static void main(String[] args) throws Exception {
        System.out.println("We're testing Banca!");
    }
}
