package Banca;

/**
 * Questa classe si occupa della gestione dei conti correnti di una Banca.
 */
public class ContoCorrente {

    protected double saldo;
    protected String proprietario;
    protected String password;

    public double Prelievo(double importo) {
        // TODO
        return 0.0;
    }

    public double Deposito(double importo) {
        // TODO
        return 0.0;
    }

}